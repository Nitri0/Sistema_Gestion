  <footer>
    <p><a class="github" href="https://github.com/broncowdd/BoZoN" title="<?php e('Fork me on github'); ?>">&nbsp;</a></p>
    <p id="version">
    	BoZoN <?php echo VERSION;  ?>

    </p>
  </footer>
</body>
</html>
